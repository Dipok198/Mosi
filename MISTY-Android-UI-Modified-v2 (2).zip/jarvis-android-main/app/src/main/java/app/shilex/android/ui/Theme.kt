package app.shilex.android.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val MistyDeepBg = Color(0xFF070510)
val MistySurfaceCard = Color(0xCC140E26)
val MistyNeonPurple = Color(0xFF9D4EDD)
val MistyElectricViolet = Color(0xFFC77DFF)
val MistyMagentaGlow = Color(0xFFE0AAFF)
val MistyOnlineGreen = Color(0xFF2EE59D)
val MistyTextPrimary = Color(0xFFFFFFFF)
val MistyTextSecondary = Color(0xFFB8A9D9)

private val Dark = darkColorScheme(
    primary = MistyElectricViolet,
    onPrimary = Color(0xFF140724),
    primaryContainer = Color(0xFF2E144D),
    onPrimaryContainer = Color(0xFFF3D9FF),
    secondary = MistyNeonPurple,
    tertiary = Color(0xFFFFB454),
    background = MistyDeepBg,
    onBackground = MistyTextPrimary,
    surface = MistyDeepBg,
    onSurface = MistyTextPrimary,
    surfaceVariant = MistySurfaceCard,
    onSurfaceVariant = MistyTextSecondary,
    surfaceContainer = Color(0xF00E081D),
    surfaceContainerLow = Color(0xE6110A24),
    surfaceContainerHigh = Color(0xFF1A1133),
    surfaceContainerHighest = Color(0xFF241747),
    outline = Color(0xFF5A2E8A),
    outlineVariant = Color(0x669D4EDD),
    error = Color(0xFFFF6B6B),
)

private val Type = Typography(
    displaySmall = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.3.sp),
)

private val Corners = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

/** MISTY is always dark: a purple-neon futuristic HUD look. */
@Composable
fun ShilexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Dark,
        typography = Type,
        shapes = Corners,
        content = content,
    )
}

val Accent: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.primary
val Background: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.background
val Surface: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.surfaceVariant
val Muted: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.onSurfaceVariant
val Warning: Color @Composable @ReadOnlyComposable get() = MaterialTheme.colorScheme.tertiary
