package app.shilex.android.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.shilex.android.assistant.Phase
import app.shilex.android.assistant.UiState
import app.shilex.android.local.ActivityLog
import app.shilex.android.local.LocalCommand
import app.shilex.android.local.LocalPhase
import app.shilex.android.task.Task
import kotlin.math.abs
import kotlin.math.sin

private data class QuickTile(
    val title: String,
    val icon: ImageVector,
    val prompt: String,
    val openSettings: Boolean = false,
    val openTools: Boolean = false,
)

@Composable
fun HomeScreen(
    state: UiState,
    localPhase: LocalPhase,
    level: Float,
    task: Task?,
    activity: List<ActivityLog.Entry>,
    wakeOn: Boolean,
    onStart: () -> Unit,
    onStartWithText: (String) -> Unit,
    onStop: () -> Unit,
    onInterrupt: () -> Unit,
    onMicDenied: () -> Unit,
    onPermissionAnswered: (Boolean) -> Unit,
    onQuick: (LocalCommand) -> String,
    onSeeActivity: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTools: () -> Unit,
    favourites: List<LocalCommand> = emptyList(),
) {
    val context = LocalContext.current
    var pendingPromptAfterMic by remember { mutableStateOf<String?>(null) }

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val queued = pendingPromptAfterMic
            pendingPromptAfterMic = null
            if (queued != null) onStartWithText(queued) else onStart()
        } else {
            pendingPromptAfterMic = null
            onMicDenied()
        }
    }

    val askForTool = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission(), onPermissionAnswered)
    LaunchedEffect(state.permissionNeeded) {
        state.permissionNeeded?.let(askForTool::launch)
    }

    val startListening: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) onStart() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    val triggerPrompt: (String) -> Unit = { prompt ->
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            onStartWithText(prompt)
        } else {
            pendingPromptAfterMic = prompt
            askMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val isSpeaking = localPhase == LocalPhase.Speaking || state.phase == Phase.Speaking
    val isListening = localPhase == LocalPhase.Listening || state.phase == Phase.Listening
    val isWorking = localPhase == LocalPhase.Doing || state.phase == Phase.Connecting
    val isLive = isSpeaking || isListening || isWorking

    val statusLabel = when {
        state.problem != null && !isLive -> "Attention"
        isSpeaking -> "Speaking..."
        isListening -> "Listening..."
        isWorking -> "Thinking..."
        else -> "Ready to help..."
    }

    val lastAssistantLine = state.lines.lastOrNull { !it.fromUser }?.text
    val bubbleText = when {
        !lastAssistantLine.isNullOrBlank() -> lastAssistantLine
        state.problem != null && !isLive -> state.problem
        isListening -> "I'm listening...
Bolिये, main sun rahi hoon."
        isWorking -> "Ek second...
Processing your request..."
        else -> null
    }

    val quickTiles = remember {
        listOf(
            QuickTile("Make a Call", Icons.Filled.Call, "Kisko call karna hai? Naam bataiye."),
            QuickTile("Send Message", Icons.Filled.ChatBubbleOutline, "Kisko WhatsApp ya SMS message bhejna hai?"),
            QuickTile("Play Music", Icons.Filled.PlayArrow, "Play my favorite song on music player"),
            QuickTile("Search Web", Icons.Filled.Public, "Aaj ki latest news aur updates batao"),
            QuickTile("Open App", Icons.Filled.Apps, "Kaunsa app open karna hai?"),
            QuickTile("Settings", Icons.Filled.Settings, "", openSettings = true),
            QuickTile("Tell Me", Icons.Filled.Lightbulb, "Mujhe aaj koi interesting fact ya tip batao"),
            QuickTile("More", Icons.Filled.DragIndicator, "", openTools = true),
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // 1. Top Header Bar: MISTY Lotus Logo + Title + Pro Badge + Settings Gear
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MistyNeonPurple.copy(alpha = 0.18f))
                        .border(1.dp, MistyElectricViolet.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Spa,
                        contentDescription = "Misty Logo",
                        tint = MistyMagentaGlow,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MISTY",
                        color = MistyElectricViolet,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                    )
                    Text(
                        text = "Your Personal AI Assistant",
                        color = MistyTextSecondary,
                        fontSize = 11.sp,
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC180F30))
                        .border(1.dp, MistyNeonPurple.copy(alpha = 0.8f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = "Pro",
                            tint = Color(0xFFFFD166),
                            modifier = Modifier.size(15.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Pro", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = "Settings",
                        tint = Color.White,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // 2. Hero Avatar Stage + Online Badge (Top-Left) + Floating Speech Bubble (Right)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(276.dp),
        ) {
            // Center Female Avatar with Glowing Neon Ring
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .semantics { contentDescription = "MISTY Avatar" }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        when {
                            isSpeaking -> onInterrupt()
                            !isLive -> startListening()
                        }
                    },
            ) {
                MistyPortrait(
                    speaking = isSpeaking,
                    listening = isListening || isWorking,
                    voiceLevel = level,
                )
            }

            // Top-Left Online Status Pill Card
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xD9140D29))
                    .border(1.dp, MistyNeonPurple.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 11.dp, vertical = 7.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (state.hasKey) MistyOnlineGreen else Warning),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (state.hasKey) "Online" else "Setup Key",
                        color = if (state.hasKey) MistyOnlineGreen else Warning,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Text(
                    text = statusLabel,
                    color = MistyTextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                )
            }

            // Right-Side Floating Speech / Greeting Bubble
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(156.dp)
                    .shadow(16.dp, RoundedCornerShape(18.dp), ambientColor = MistyNeonPurple.copy(alpha = 0.4f))
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xE6160E2E))
                    .border(1.2.dp, MistyElectricViolet.copy(alpha = 0.75f), RoundedCornerShape(18.dp))
                    .padding(11.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AnimatedContent(targetState = bubbleText, label = "speechBubble") { dynamicText ->
                    if (dynamicText == null) {
                        Text(
                            text = buildAnnotatedString {
                                append("Hello! 👋
I am ")
                                withStyle(SpanStyle(color = MistyMagentaGlow, fontWeight = FontWeight.Bold)) {
                                    append("Misty...")
                                }
                                append("
How can I help you?")
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Start,
                        )
                    } else {
                        Text(
                            text = dynamicText,
                            color = Color.White,
                            fontSize = 11.5.sp,
                            lineHeight = 15.sp,
                            maxLines = 5,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Start,
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Icon(
                    imageVector = Icons.Filled.FavoriteBorder,
                    contentDescription = "Heart",
                    tint = MistyMagentaGlow,
                    modifier = Modifier.size(15.dp),
                )
            }
        }

        // 3. Dual Neon Audio Waveforms + Center Glowing Mic Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            NeonWaveBars(active = isLive, level = level, modifier = Modifier.weight(1f).height(38.dp))
            Spacer(Modifier.width(10.dp))

            Box(
                modifier = Modifier
                    .size(74.dp)
                    .shadow(20.dp, CircleShape, ambientColor = MistyNeonPurple, spotColor = MistyMagentaGlow)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                if (isLive) Color(0xFF6A1B9A) else MistyNeonPurple,
                                Color(0xFF2B1055),
                            )
                        )
                    )
                    .border(2.5.dp, MistyMagentaGlow, CircleShape)
                    .clickable { if (isLive) onStop() else startListening() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (isLive) Icons.Filled.Close else MicIcon,
                    contentDescription = if (isLive) "Stop listening" else "Tap to Speak",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp),
                )
            }

            Spacer(Modifier.width(10.dp))
            NeonWaveBars(active = isLive, level = level, modifier = Modifier.weight(1f).height(38.dp))
        }

        Text(
            text = when {
                isSpeaking -> "Speaking (Tap X to stop)"
                isListening -> "Listening..."
                isWorking -> "Connecting..."
                else -> "Tap to Speak"
            },
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
        )

        // Active Task Card if an automation/task is running
        val recentTask = task?.takeIf { isLive || System.currentTimeMillis() - it.at < 120_000L }
        recentTask?.let {
            TaskCard(it, Modifier.padding(bottom = 10.dp))
        }

        // 4. 2x4 Grid of 8 Glassmorphic Purple Quick Action Tiles
        Column(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            quickTiles.chunked(4).forEach { rowTiles ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    rowTiles.forEach { tile ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xCC1B1136), Color(0xCC110A24))
                                    )
                                )
                                .border(1.dp, MistyNeonPurple.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                                .clickable {
                                    when {
                                        tile.openSettings -> onOpenSettings()
                                        tile.openTools -> onOpenTools()
                                        else -> triggerPrompt(tile.prompt)
                                    }
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                imageVector = tile.icon,
                                contentDescription = tile.title,
                                tint = MistyElectricViolet,
                                modifier = Modifier.size(22.dp),
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = tile.title,
                                color = Color.White,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun NeonWaveBars(active: Boolean, level: Float, modifier: Modifier = Modifier) {
    val barCount = 18
    Canvas(modifier) {
        val gap = size.width / barCount
        val midY = size.height / 2f
        val effectiveLevel = if (active) level.coerceIn(0.22f, 1f) else 0.35f
        for (i in 0 until barCount) {
            val x = gap * (i + 0.5f)
            val envelope = 1f - abs(i - barCount / 2f) / (barCount / 2f) * 0.65f
            val wave = 0.30f + 0.70f * abs(sin(i * 0.75f + effectiveLevel * 6f))
            val halfH = (size.height * 0.46f) * envelope * wave * (if (active) 1f else 0.55f)
            drawLine(
                color = if (active) MistyMagentaGlow else MistyNeonPurple.copy(alpha = 0.65f),
                start = Offset(x, midY - halfH),
                end = Offset(x, midY + halfH),
                strokeWidth = (gap * 0.42f).coerceAtLeast(2.5f),
                cap = StrokeCap.Round,
            )
        }
    }
}
