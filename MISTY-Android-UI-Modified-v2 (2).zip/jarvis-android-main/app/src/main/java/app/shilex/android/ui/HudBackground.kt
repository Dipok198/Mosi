package app.shilex.android.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Deep purple-black futuristic backdrop with ambient violet nebula glow. */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFF0A0618), Color(0xFF070510), Color(0xFF120A26))
            )
        )
        val glowCentre = Offset(size.width * 0.45f, size.height * 0.30f)
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF9D4EDD).copy(alpha = 0.22f), Color.Transparent),
                glowCentre,
                size.width * 0.95f
            ),
            radius = size.width * 0.95f,
            center = glowCentre,
        )
    }
}
