package app.shilex.android.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.shilex.android.R

@Composable
fun MistyAvatar(
    speaking: Boolean,
    listening: Boolean,
    modifier: Modifier = Modifier,
    diameter: Dp = 88.dp,
    voiceLevel: Float = 0f,
) {
    val transition = rememberInfiniteTransition(label = "mistyAvatarIdle")
    val drift by transition.animateFloat(
        initialValue = -2.5f,
        targetValue = 2.5f,
        animationSpec = infiniteRepeatable(tween(2_800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "avatarDrift",
    )
    val smoothLevel by animateFloatAsState(
        targetValue = voiceLevel.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "avatarLevel",
    )
    val scale by animateFloatAsState(
        targetValue = if (speaking) 1.03f + (smoothLevel * 0.05f) else if (listening) 1.015f + (smoothLevel * 0.03f) else 1f,
        animationSpec = tween(220),
        label = "avatarStateScale",
    )
    val ring = when {
        speaking -> MistyMagentaGlow
        listening -> MistyElectricViolet
        else -> MistyNeonPurple
    }

    Box(
        modifier = modifier
            .size(diameter)
            .graphicsLayer {
                translationY = drift
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (speaking) 28.dp else 18.dp,
                shape = CircleShape,
                ambientColor = ring.copy(alpha = 0.55f),
                spotColor = ring.copy(alpha = 0.75f),
            )
            .background(
                Brush.radialGradient(
                    listOf(ring.copy(alpha = if (speaking) 0.55f else 0.32f), Color(0xFF140B29))
                ),
                CircleShape,
            )
            .border(
                width = if (speaking) 3.dp else 2.2.dp,
                brush = Brush.linearGradient(listOf(MistyNeonPurple, MistyMagentaGlow, MistyElectricViolet)),
                shape = CircleShape,
            )
            .clip(CircleShape)
            .semantics { contentDescription = "MISTY female avatar" },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.misty_avatar),
            contentDescription = "MISTY avatar",
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier
                .size(diameter - 8.dp)
                .clip(CircleShape),
        )
    }
}

/** Large neon halo portrait stage used by the main MISTY Home dashboard. */
@Composable
fun MistyPortrait(
    speaking: Boolean,
    listening: Boolean,
    voiceLevel: Float = 0f,
    modifier: Modifier = Modifier,
) {
    MistyAvatar(
        speaking = speaking,
        listening = listening,
        voiceLevel = voiceLevel,
        diameter = 236.dp,
        modifier = modifier,
    )
}
